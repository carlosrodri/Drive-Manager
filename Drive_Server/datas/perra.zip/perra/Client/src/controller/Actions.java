package controller;

public enum Actions {
	SEND, ACCEPT, CHANGE_IP

}
